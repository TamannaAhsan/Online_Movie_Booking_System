<?php 



	$page = 'all_movies';
	$title = 'All movies';

	include 'index.php';

 ?>