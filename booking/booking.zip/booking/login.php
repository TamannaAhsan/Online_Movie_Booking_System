<?php 



	$page = 'login';

	include 'index.php';

 ?>