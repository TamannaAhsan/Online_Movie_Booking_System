<h2>Cineplex Bangladesh</h2>
<hr>
<div class="row">
	<div class="col-6">
		<p style="padding-top:10px;">Star Cineplex bd Movie Schedule & Ticket Price. Star Cineplex bd is the most Popular Cinema hall in Dhaka, Bangladesh. You know that many People like seeing the Movie going to Cinema Hall. The Star Cineplex Cinema hall accept by Rich Class Society beside Middle-Class. Are you Looking Star Cineplex bd Movie Schedule & Ticket Price? No tension. This post has to all information about Star Cineplex bd Cinema Hall.</p>
		<h3>Movie Ticket Price</h3>
		<p>Regular-100.00 Taka</p>
		<h3>Show time</h3>
		<p>11am - 02pm</p>
		<p>3pm - 06pm</p>
	</div>
	<div class="col-6">
		<img src="assets/public/images/cineplex.jpg" width="100%">
	</div>
</div>
<div class="row">
	<?php include 'inc/widgets.php'; ?>
</div>