

<h2>Contact page</h2>
<hr>

<div class="row">
	<div class="col-8">
		
		<h2 class="title_page">Contact Us</h2>
		<h4><span class="glyphicon glyphicon-phone"></span> Hot Line</h4>
		<p> Cell: 01755665544</p>
		<h4><span class="glyphicon glyphicon-phone-alt"></span> Call Us</h4>
		<p> Tel: 9138260, 9134098 9141332, 9140819</p>
		<h4><span class="glyphicon glyphicon-envelope"></span> Email</h4>
		<p><span>Customer Service:</span> <a href="mailto:customerservices@cineplexbd.com">customerservices@cineplexbd.com</a> </p>
		<p><span>General Information:</span> <a href="mailto:info@cineplexbd.com">info@cineplexbd.com</a></p>

		<p><span>Membership Coordinator:</span> <a href="mailto:member@cineplexbd.com">member@cineplexbd.com</a></p>
		<p><span>Hr/Admin Department:</span> <a href="mailto:hr@cineplexbd.com m">hr@cineplexbd.com </a></p>
		<p><span>Executive Director:</span> <a href="mailto:ed@cineplexbd.com">ed@cineplexbd.com</a></p>
		<p><span>Managing Director:</span> <a href="mailto:mrahman@cineplexbd.com">mrahman@cineplexbd.com</a></p>
		
	</div>
	<div class="col-4">
		<div class="mail-box side-module">
		            <header>
		              <h2>Show Motion Limited</h2>
		            </header>
		            <div class="body">
		              <h3>Star Cineplex, Bashundhara City</h3>
		              <p>Level 8, Bashundhara City, 13/3 Ka, Panthapath, Tejgaon, Dhaka-1205</p>
		            </div>
		            <div class="body">
		              <h3>Star Cineplex, Shimanto Shambhar</h3>
		              <p>Level-9, Shimanto Shambhar, Pilkhana, Dhanmondi-2, Dhaka-1205.</p>
		            </div>
		            <div class="body">
		              <h3>Star Cineplex, SKS Tower</h3>
		              <p>Level-3, SKS Tower, Mohakhali, Dhaka-1208.</p>
		            </div>
		          </div>
	</div>
</div>

