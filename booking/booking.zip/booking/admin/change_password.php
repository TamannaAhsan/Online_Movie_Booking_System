<?php 

	$page = 'change_password';
	include 'dashboard.php';
 ?>