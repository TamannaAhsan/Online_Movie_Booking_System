<?php 
	
	$page= 'edit_movie';
	include 'dashboard.php';

 ?>