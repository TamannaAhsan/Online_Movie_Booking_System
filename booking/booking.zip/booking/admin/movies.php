<?php 

	$page = 'movies';
	include 'dashboard.php';

 ?>