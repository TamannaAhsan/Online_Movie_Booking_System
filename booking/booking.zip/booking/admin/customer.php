<?php 

	$page = 'customer';
	include 'dashboard.php';
 ?>