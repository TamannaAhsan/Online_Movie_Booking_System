<?php 

	$page = 'category';
	include 'dashboard.php';

 ?>