<?php 
	
	$page = 'edit_category';
	include 'dashboard.php';

 ?>