<?php 

	$page = 'new_movie';
	include 'dashboard.php';

 ?>