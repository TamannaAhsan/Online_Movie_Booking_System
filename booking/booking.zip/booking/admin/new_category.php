<?php 

	$page = 'new_category';
	include 'dashboard.php';

 ?>