<?php 

	$page='booking';
	include 'dashboard.php';

?>