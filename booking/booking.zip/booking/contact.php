<?php 



	$page = 'contact';
	$title = 'Contact';

	include 'index.php';

 ?>