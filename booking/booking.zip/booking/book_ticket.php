<?php 
	
	$page = 'book_ticket';
	$title = 'Book ticket';
	include 'index.php';

 ?>