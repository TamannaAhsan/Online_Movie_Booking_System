<?php 

	$page='check_in';
	$title='Check in';
	include 'index.php';

 ?>