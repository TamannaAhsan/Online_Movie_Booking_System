
<div class="col-4" style="padding:10px">
	<h2>About</h2>
	<hr>
	<p>Cineplex bd Movie Schedule & Ticket Price. Star Cineplex bd is the most Popular Cinema hall in Dhaka, Bangladesh. You know that many People like seeing the Movie going to Cinema Hall.</p> <p>The Star Cineplex Cinema hall accept by Rich Class Society beside Middle-Class. Are you Looking Star Cineplex bd Movie Schedule & Ticket Price? No tension. This post has to all information about Star Cineplex bd Cinema Hall.</p>
</div>
<div class="col-4" style="padding:10px">
	<h2>Show Time/Price</h2>
	<hr>
	<h3>Movie Ticket Price</h3>
	<p>Regular-100.00 Taka</p>
	<h3>Show time</h3>
	<p>11am - 02pm</p>
	<p>3pm - 06pm</p>
</div>
<div class="col-4" style="padding:10px">
	<h2>Contact</h2>
	<hr>
	
	  <div class="">
	    <h3>Star Cineplex, Bashundhara City</h3>
	    <p>Level 8, Bashundhara City, 13/3 Ka, Panthapath, Tejgaon, Dhaka-1205</p>
	  </div>
	  <div class="">
	    <h3>Star Cineplex, Shimanto Shambhar</h3>
	    <p>Level-9, Shimanto Shambhar, Pilkhana, Dhanmondi-2, Dhaka-1205.</p>
	  </div>
	  <div class="">
	    <h3>Star Cineplex, SKS Tower</h3>
	    <p>Level-3, SKS Tower, Mohakhali, Dhaka-1208.</p>
	  </div>
</div>
