<div class="slider">
  <div><img src="assets/public/images/1.jpg" width="100%"></div>
  <div><img src="assets/public/images/2.jpg" width="100%"></div>
</div>
