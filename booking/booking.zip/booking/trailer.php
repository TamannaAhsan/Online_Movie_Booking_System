<?php 
	
	$page = 'trailer';
	$title = 'Trailer';
	include 'index.php';

 ?>