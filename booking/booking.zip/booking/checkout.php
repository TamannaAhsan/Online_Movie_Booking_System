<?php 

	$page = 'checkout';
	$title = 'Checkout';
	include 'index.php';

 ?>