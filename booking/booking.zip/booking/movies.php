<?php 
	
	$page = 'movies';
	$title = 'Movies';
	include 'index.php';

 ?>