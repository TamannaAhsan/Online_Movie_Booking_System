<?php 
	
	$page = 'show_movie';
	$title = 'Show movie';
	include 'index.php';

 ?>