<?php 
$page='category';
$title = 'Movie';
include 'index.php';
?>