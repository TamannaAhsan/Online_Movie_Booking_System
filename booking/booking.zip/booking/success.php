<?php 
	
	$page = 'success';
	$title = 'Booking successful';
	include 'index.php';

 ?>