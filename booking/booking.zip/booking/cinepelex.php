<?php 



	$page = 'cinepelex';
	$title = 'Cinepelex';

	include 'index.php';

 ?>